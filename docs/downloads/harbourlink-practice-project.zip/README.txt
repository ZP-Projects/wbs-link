WBS↔LINK HarbourLink Practice Project

This fictional synthetic project is the standard first-run practice experience for WBS↔LINK.

Recommended sequence
1. Read case_briefing.md.
2. Read mission_guide.md.
3. Use only the Cycle 1 files first.
4. Complete the WBS↔LINK journey and review Project Intelligence and outputs.
5. Then use the Cycle 2 files and review what remained valid and what changed.

Included source types
- Owner WBS
- Contractor schedule
- Monthly cost / forecast
- Package register

This package contains fictional synthetic practice data only. No real client or confidential project data is included.
