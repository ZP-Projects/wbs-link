# WBS↔LINK Practice package

Start with `HOW_TO.md`.

This package contains a synthetic three-period project-controls mapping problem. Your target WBS is:

`practice/files/owner/owner_scope_structure.xlsx`

The public reference mapping is:

`practice/answers_practice.csv`

Build your submission using `ANSWER_TEMPLATE.csv`. Use a WBS `Cell ID`, `NO_WBS`, `NEW_SCOPE`, `UNSURE`, or `A|B` where one record genuinely spans two WBS cells. For the GC SOV, use **Line No** as `record_id`.

For every answered mapping, confidence must be exactly `high`, `med` or `low`. With `UNSURE`, use blank or `low`.

## Score locally

From this extracted folder:

`python scorer/score.py my_answers.csv --set practice --exceptions my_exceptions.csv`

The Practice set is repeatable. Its reference mapping is public, so use this package to understand the format before taking the hidden Challenge.
