# WBS↔LINK Challenge package

Start with `HOW_TO.md`.

This package contains the hidden-reference WBS↔LINK Challenge. Your target WBS is:

`challenge/files/owner/owner_scope_structure.xlsx`

Build your submission using `ANSWER_TEMPLATE.csv`. Use a WBS `Cell ID`, `NO_WBS`, `NEW_SCOPE`, `UNSURE`, or `A|B` where one record genuinely spans two WBS cells. For the GC SOV, use **Line No** as `record_id`.

For every answered mapping, confidence must be exactly `high`, `med` or `low`. With `UNSURE`, use blank or `low`.

The reference mapping is intentionally not included. The hidden Challenge allows one scored attempt per GitHub user, so complete the Practice set first.

Submit through the WBS↔LINK GitHub submission form when ready. Never include real client, employer or confidential project information.
