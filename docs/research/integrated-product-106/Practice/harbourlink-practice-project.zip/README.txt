HARBOURLINK · SYNTHETIC PRACTICE

Read case_briefing.md for context and mission_guide.md for the full two-cycle workflow and separate approvals. Begin with Cycle 1; revise only schedule, cost and package sources in Cycle 2. Retain the June Owner WBS. Use fictional data only; no answer key is included.
